#pragma once

template <typename T>
T minus(T a, T b) {
    return a - b;
}