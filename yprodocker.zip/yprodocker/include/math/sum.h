#pragma once

template <typename T>
T sum(T a, T b) {
    return a + b;
}