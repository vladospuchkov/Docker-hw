#pragma once

template <typename T>
T mul(T a, T b) {
    return a * b;
}